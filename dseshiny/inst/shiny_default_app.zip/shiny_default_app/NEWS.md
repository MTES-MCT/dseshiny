# DSFRShiny 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.
* Added a `LICENSE.md` file to track changes to the package.
* Added a `README.Rmd` file to track changes to the package.
* Added a `CODE_OF_CONDUCT.md` file to track changes to the package.
