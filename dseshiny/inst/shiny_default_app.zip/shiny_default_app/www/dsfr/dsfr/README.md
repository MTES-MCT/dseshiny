# dsfr-deprecated

## Utilisation
Afin d’utiliser le composant `dsfr-deprecated`, il est nécessaire d’ajouter les fichiers de styles et de scripts présents dans le dossier dist dans l'ordre suivant :
```html
<html>
  <head>
    <link href="css/dsfr-deprecated/dsfr-deprecated.min.css" rel="stylesheet">
  </head>
  <body>
    <script type="module" href="js/dsfr-deprecated/dsfr-deprecated.module.min.js" ></script>
    <script type="text/javascript" nomodule href="js/dsfr-deprecated/dsfr-deprecated.nomodule.min.js" ></script>
  </body>
</html>
```