# table

Les tableaux sont utilisés pour organiser et afficher les informations d'un jeu de données.

## Dépendances
```shell
table
└─ core
```

## Utilisation
Afin d’utiliser le composant `table`, il est nécessaire d’ajouter les fichiers de styles et de scripts présents dans le dossier dist dans l'ordre suivant :
```html
<html>
  <head>
    <link href="css/core/core.min.css" rel="stylesheet">
    <link href="css/table/table.min.css" rel="stylesheet">
  </head>
  <body>
    <script type="text/javascript" nomodule href="js/legacy/legacy.nomodule.min.js" ></script>
    <script type="module" href="js/core/core.module.min.js" ></script>
    <script type="text/javascript" nomodule href="js/core/core.nomodule.min.js" ></script>
    <script type="module" href="js/table/table.module.min.js" ></script>
    <script type="text/javascript" nomodule href="js/table/table.nomodule.min.js" ></script>
  </body>
</html>
```

## Documentation

Consulter [la documentation](https://gouvfr.atlassian.net/wiki/spaces/DB/pages/312016971/Tableau+-+Table) sur le module Tableaux