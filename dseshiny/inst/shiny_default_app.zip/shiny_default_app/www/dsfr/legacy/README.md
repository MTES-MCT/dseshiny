# legacy

Ce package est utilisé de manière globale pour la compatibilité Internet Explorer 11 du Design System de l'Etat.

## Utilisation
Afin d’utiliser le composant `legacy`, il est nécessaire d’ajouter les fichiers de styles et de scripts présents dans le dossier dist dans l'ordre suivant :
```html
<html>
  <head>
  </head>
  <body>
    <script type="text/javascript" nomodule href="js/legacy/legacy.nomodule.min.js" ></script>
  </body>
</html>
```